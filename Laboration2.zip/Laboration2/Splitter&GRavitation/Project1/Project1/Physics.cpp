#include "Physics.h"
#include <iostream>

Physics::Physics() {}

Physics::Physics(v2 position, v2 size, v2 velocity, v2 restitution) {
	this->position = position;
	this->size = size;
	this->velocity = velocity;
	this->restitution = restitution;

	srand(time(NULL));
}

Physics::~Physics() {}

v2 Physics::getPosition() {
	return this->position;
}

v2 Physics::getSize() {
	return this->size;
}

v2 Physics::getVelocity() {
	return this->velocity;
}

v2 Physics::getRestitution() {
	return this->restitution;
}

void Physics::setPosition(v2 position) {
	this->position = position;
}

void Physics::setSize(v2 size) {
	this->size = size;
}

void Physics::setVelocity(v2 velocity) {
	this->velocity = velocity;
}

void Physics::setRestitution(v2 restitution) {
	this->restitution = restitution;
}

// Make ball slow down over time
void Physics::applyForce(const v2 &force) {
	velocity = velocity + force;
}

float Physics::generateRandomNumber(float min, float max) {
	return ((float(rand()) / float(RAND_MAX)) * (max - min)) + min;
}

//Collision and calculating new direction.
void Physics::update(float delta, const SDL_Rect &area) {

	acceleration.x = velocity.x / delta;
	acceleration.y = velocity.y / delta;
	
	acceleration -= restitution;

	v2 randomDirection;
	randomDirection.x = generateRandomNumber(-.1f, .5f);
	randomDirection.y = generateRandomNumber(-.1f, .5f);
	
	printf("\n X: (1000) %f", randomDirection.x);
	printf("	Y: (500) %f", randomDirection.y);
	
	applyForce(randomDirection);

	randomDirection.normalize();

	printf("\n Normalized X: %f", randomDirection.x);
	printf("	Normalized Y: %f", randomDirection.y);
	printf("\n\n");

	v2 newVelocity;
	newVelocity.x = delta * acceleration.x  * randomDirection.x + velocity.x;
	newVelocity.y = delta * acceleration.y * randomDirection.y + velocity.y;

	v2 newPosition;
	newPosition.x = position.x + delta * newVelocity.x + randomDirection.x;
	newPosition.y = position.y + delta * newVelocity.y + randomDirection.y;

	position = newPosition;
	velocity = newVelocity;

	if ((position.y > area.h + 10) || (position.x > area.w + 10)) {
		//Kill particle...
		position.x = area.w + 10;
		position.y = area.h + 10;
	}

}